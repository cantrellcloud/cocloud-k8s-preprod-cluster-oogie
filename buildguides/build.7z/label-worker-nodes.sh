kubectl label node kubework125 node-role.kubernetes.io/worker=
kubectl label node kubework126 node-role.kubernetes.io/worker=
kubectl label node kubework127 node-role.kubernetes.io/worker=
kubectl label node kubework128 node-role.kubernetes.io/worker=
